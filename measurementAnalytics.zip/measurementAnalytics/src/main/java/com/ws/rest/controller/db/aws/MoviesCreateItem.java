package com.ws.rest.controller.db.aws;

/**
 * Created by n465449 on 16-Feb-18.
 */
import java.util.HashMap;
import java.util.Map;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.PutItemOutcome;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.ws.rest.pojo.AirwayConstant;

public class MoviesCreateItem {

    public static void main(String[] args) throws Exception {

        BasicAWSCredentials awsCreds = new BasicAWSCredentials("AKIAIA4H744NZ5RNKOVA", "aDzCKHi5gQnTLrB+JxDwubXmJm5b0SpCIBx7azr3");
        AmazonDynamoDB client = AmazonDynamoDBClientBuilder.standard().withCredentials(new AWSStaticCredentialsProvider(awsCreds))
                .withEndpointConfiguration(new AwsClientBuilder.EndpointConfiguration("http://localhost:8000", "ap-south-1"))
                .build();

        DynamoDB dynamoDB = new DynamoDB(client);

        Table table = dynamoDB.getTable("CARGO_DIMENSIONS");

       /* int year = 2010;
        String title = "The Big New Movie 2";

        final Map<String, Object> infoMap = new HashMap<String, Object>();
        infoMap.put("plot", "Updating the item.");
        infoMap.put("rating", 0);
        infoMap.put("ratings", 2);

        try {
            System.out.println("Adding a new item...");
            PutItemOutcome outcome = table
                    .putItem(new Item().withPrimaryKey("year", year, "title", title).with("name","yuvaraj").withMap("info", infoMap));

            System.out.println("PutItem succeeded:\n" + outcome.getPutItemResult());

        }
        catch (Exception e) {
            System.err.println("Unable to add item: " + year + " " + title);
            System.err.println(e.getMessage());
        }*/

        boolean results = true;
        final Map<String, Object> infoMap = new HashMap<String, Object>();
        infoMap.put(AirwayConstant.HEIGHT,"0");
        infoMap.put(AirwayConstant.LENGTH,"0");
        infoMap.put(AirwayConstant.WIDTH,"0");
        infoMap.put(AirwayConstant.MANUAL_HEIGHT,103);
        infoMap.put(AirwayConstant.MANUAL_LENGTH,13);
        infoMap.put(AirwayConstant.MANUAL_WIDTH,203);

        try
        {
            System.out.println("Adding a new item..."+infoMap);
            PutItemOutcome outcome = table.putItem(new Item().withPrimaryKey(AirwayConstant.AIRWAY_BAR_ID, "AWBC20180203")
                    .withInt(AirwayConstant.PIECE_ID, 3).withMap(AirwayConstant.DIMENSIONS, infoMap));
            System.out.println("outcome.getItem:"+outcome.getItem());
            System.out.println("PutItem succeeded:\n" + outcome.getPutItemResult());

        }
        catch (Exception e) {
            System.out.println("Unable to add item: " +"AWBC20180201");
            System.out.println(e.getMessage());
            results = false;
        }

    }
}
