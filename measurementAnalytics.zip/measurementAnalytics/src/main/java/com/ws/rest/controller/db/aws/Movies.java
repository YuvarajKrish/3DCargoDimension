package com.ws.rest.controller.db.aws;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.model.ListTablesRequest;
import com.amazonaws.services.dynamodbv2.model.ListTablesResult;
import com.amazonaws.services.dynamodbv2.model.TableDescription;
import com.ws.rest.pojo.AirwayConstant;

import java.util.List;

/**
 * Created by YK00480031 on 23-02-2018.
 */
public class Movies {


    public static void main(String[] arg)
    {
        BasicAWSCredentials awsCreds = new BasicAWSCredentials("AKIAIA4H744NZ5RNKOVA", "aDzCKHi5gQnTLrB+JxDwubXmJm5b0SpCIBx7azr3");
        AmazonDynamoDB client = AmazonDynamoDBClientBuilder.standard().withCredentials(new AWSStaticCredentialsProvider(awsCreds))
                .withEndpointConfiguration(new AwsClientBuilder.EndpointConfiguration("http://localhost:8000", "ap-south-1"))
                .build();

        DynamoDB dynamoDB = new DynamoDB(client);

        /*final AmazonDynamoDB ddb = AmazonDynamoDBClientBuilder.defaultClient();*/
        ListTablesRequest request;

        boolean more_tables = true;
        String last_name = null;
            try
            {
                TableDescription tableDescription = dynamoDB.getTable(AirwayConstant.AIRWAY_TABLE).describe();
                System.out.format(
                        "Name: %s:\n" + "Status: %s \n" + "Provisioned Throughput (read capacity units/sec): %d \n"
                                + "Provisioned Throughput (write capacity units/sec): %d \n",
                        tableDescription.getTableName(), tableDescription.getTableStatus(),
                        tableDescription.getProvisionedThroughput().getReadCapacityUnits(),
                        tableDescription.getProvisionedThroughput().getWriteCapacityUnits());

                System.out.println("Attri:"+tableDescription.getAttributeDefinitions());

            }catch (Exception e)
            {
                System.out.println("Exception:"+e);
             }


        }
}
