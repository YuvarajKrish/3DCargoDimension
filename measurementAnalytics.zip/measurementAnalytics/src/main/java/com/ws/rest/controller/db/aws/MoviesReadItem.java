package com.ws.rest.controller.db.aws;

/**
 * Created by n465449 on 16-Feb-18.
 */
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.document.*;
import com.amazonaws.services.dynamodbv2.document.spec.GetItemSpec;
import com.amazonaws.services.dynamodbv2.document.spec.ScanSpec;
import com.amazonaws.services.dynamodbv2.document.utils.NameMap;
import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.ws.rest.pojo.AirwayConstant;
import com.ws.rest.pojo.AirwayDimensionRequest;
import com.ws.rest.pojo.AirwayDimensionResponse;
import com.ws.rest.pojo.Dimensions;


import java.util.Iterator;

public class MoviesReadItem {

    public static void main(String[] args) throws Exception {

        BasicAWSCredentials awsCreds = new BasicAWSCredentials("AKIAIA4H744NZ5RNKOVA", "aDzCKHi5gQnTLrB+JxDwubXmJm5b0SpCIBx7azr3");
        AmazonDynamoDB client = AmazonDynamoDBClientBuilder.standard().withCredentials(new AWSStaticCredentialsProvider(awsCreds))
                .withEndpointConfiguration(new AwsClientBuilder.EndpointConfiguration("http://localhost:8000", "ap-south-1"))
                .build();

        DynamoDB dynamoDB = new DynamoDB(client);

        //Table table = dynamoDB.getTable("Movies");
        Table table = dynamoDB.getTable(AirwayConstant.AIRWAY_TABLE);

       /* int year = 2015;
        String title = "The Big New Movie 2";

        GetItemSpec spec = new GetItemSpec().withPrimaryKey("year", year, "title", title);

        try {
            System.out.println("Attempting to read the item...");
            Item outcome = table.getItem(spec);

            System.out.println("GetItem succeeded: " + outcome);

        }
        catch (Exception e) {
            System.err.println("Unable to read item: " + year + " " + title);
            System.err.println(e.getMessage());
        }

       ScanSpec scanSpec = new ScanSpec().withProjectionExpression("#yr, title, info.rating")
                .withFilterExpression("#yr between :start_yr and :end_yr").withNameMap(new NameMap().with("#yr", "year"))
                .withValueMap(new ValueMap().withNumber(":start_yr", 1000).withNumber(":end_yr", 3017));*/

    ScanSpec scanSpec = new ScanSpec().withProjectionExpression(AirwayConstant.AIRWAY_BAR_ID+","+AirwayConstant.PIECE_ID+","
                +AirwayConstant.DIMENSIONS+"."+AirwayConstant.MANUAL_HEIGHT+","
                +AirwayConstant.DIMENSIONS+"."+AirwayConstant.MANUAL_LENGTH+","
                +AirwayConstant.DIMENSIONS+"."+AirwayConstant.MANUAL_WIDTH+","
            +AirwayConstant.DIMENSIONS+"."+AirwayConstant.HEIGHT+","
            +AirwayConstant.DIMENSIONS+"."+AirwayConstant.LENGTH+","
            +AirwayConstant.DIMENSIONS+"."+AirwayConstant.WIDTH);
                  //.withFilterExpression("#pId > 0").withNameMap(new NameMap().with("#pId", AirwayConstant.PIECE_ID));
         /*
        */

        try {

           /* ObjectMapper obj = new ObjectMapper();

            Dimensions dimensions = new Dimensions();
            dimensions.setHeight("404");
            dimensions.setLength("544");
            dimensions.setWidth("44");
            AirwayDimensionRequest request = new AirwayDimensionRequest();
            request.setAirWayBarCode("AWBC10200404");
            request.setAirWayBillNo("AWBC102004");
            request.setPieceId("04");
            request.setDimensions(dimensions);

            System.out.println(obj.writeValueAsString(request));*/

            System.out.println("-----------Scan-------------- " + scanSpec.getProjectionExpression());
            ItemCollection<ScanOutcome> items = table.scan(scanSpec);

            Iterator<Item> iter = items.iterator();
            while (iter.hasNext()) {
                Item item = iter.next();
                System.out.println(item.toString());

            }

        }
        catch (Exception e) {
            System.err.println("Unable to scan the table:");
            System.err.println(e.getMessage());
        }

    }
}