package com.ws.rest.pojo;

import java.util.List;

/**
 * Created by n465449 on 15-Feb-18.
 */
public class Airline {

    private String AirlineId;

    private List<String> pieceId;


    public String getAirlineId() {
        return AirlineId;
    }

    public void setAirlineId(String airlineId) {
        AirlineId = airlineId;
    }

    public List<String> getPieceId() {
        return pieceId;
    }

    public void setPieceId(List<String> pieceId) {
        this.pieceId = pieceId;
    }
}
