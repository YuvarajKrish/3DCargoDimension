package com.ws.rest.pojo;

/**
 * Created by n465449 on 15-Feb-18.
 */
public class Dimensions {

    private String height;
    private String lengths;
    private String width;
    private String manualHeight;
    private String manualLengths;
    private String manualWidth;

    public String getManualHeight() {
        return manualHeight;
    }

    public void setManualHeight(String manualHeight) {
        this.manualHeight = manualHeight;
    }

    public String getManualLengths() {
        return manualLengths;
    }

    public void setManualLengths(String manualLengths) {
        this.manualLengths = manualLengths;
    }

    public String getManualWidth() {
        return manualWidth;
    }

    public void setManualWidth(String manualWidth) {
        this.manualWidth = manualWidth;
    }




    public String getHeight() {
        return height;
    }

    public void setHeight(String height) {
        this.height = height;
    }

    public String getLength() {
        return lengths;
    }

    public void setLength(String length) {
        this.lengths = length;
    }

    public String getWidth() {
        return width;
    }

    public void setWidth(String width) {
        this.width = width;
    }

    @Override
    public String toString() {
        return "Dimensions{" +
                "height='" + height + '\'' +
                ", length='" + lengths + '\'' +
                ", width='" + width + '\'' +
                ",manualHeight='" + manualHeight + '\'' +
                ", manualLengths='" + manualLengths + '\'' +
                ", manualWidth='" + manualWidth + '\'' +
                '}';
    }
}
