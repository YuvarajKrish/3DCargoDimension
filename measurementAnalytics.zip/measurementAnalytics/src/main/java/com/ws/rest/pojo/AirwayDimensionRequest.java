package com.ws.rest.pojo;

import java.io.Serializable;

/**
 * Created by n465449 on 19-Feb-18.
 */
public class AirwayDimensionRequest  implements Serializable {

    private String airWayBarCode;
    private String airWayBillNo;
    private String pieceId;
    private Dimensions dimensions;


    public String getAirWayBarCode() {
        return airWayBarCode;
    }

    public void setAirWayBarCode(String airWayBarCode) {
        this.airWayBarCode = airWayBarCode;
    }

    public String getAirWayBillNo() {
        return airWayBillNo;
    }

    public void setAirWayBillNo(String airWayBillNo) {
        this.airWayBillNo = airWayBillNo;
    }

    public String getPieceId() {
        return pieceId;
    }

    public void setPieceId(String pieceId) {
        this.pieceId = pieceId;
    }

    public Dimensions getDimensions() {
        return dimensions;
    }

    public void setDimensions(Dimensions dimensions) {
        this.dimensions = dimensions;
    }

    @Override
    public String toString() {
        return "AirwayDimensionRequest{" +
                "airWayBarCode='" + airWayBarCode + '\'' +
                ", airWayBillNo='" + airWayBillNo + '\'' +
                ", pieceId='" + pieceId + '\'' +
                ", dimensions=" + dimensions +
                '}';
    }
}
