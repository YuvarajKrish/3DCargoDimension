package com.ws.rest.controller.db.aws;

/**
 * Created by n465449 on 16-Feb-18.
 *
 * https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/GettingStarted.Java.04.html
 *
 */

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.spec.DeleteItemSpec;
import com.ws.rest.pojo.AirwayConstant;

public class MoviesDeleteTable {

    public static void main(String[] args) throws Exception {

        BasicAWSCredentials awsCreds = new BasicAWSCredentials("AKIAIA4H744NZ5RNKOVA", "aDzCKHi5gQnTLrB+JxDwubXmJm5b0SpCIBx7azr3");
        AmazonDynamoDB client = AmazonDynamoDBClientBuilder.standard().withCredentials(new AWSStaticCredentialsProvider(awsCreds))
                .withEndpointConfiguration(new AwsClientBuilder.EndpointConfiguration("http://localhost:8000", "ap-south-1"))
                .build();

        DynamoDB dynamoDB = new DynamoDB(client);

        Table table = dynamoDB.getTable(AirwayConstant.AIRWAY_TABLE);

   try {
            System.out.println("Issuing DeleteTable request for " + table);
            table.delete();
            System.out.println("Waiting for " + table + " to be deleted...this may take a while...");
            table.waitForDelete();

        }
        catch (Exception e) {
            System.err.println("DeleteTable request failed for " + table);
            System.err.println(e.getMessage());
        }
    }
}