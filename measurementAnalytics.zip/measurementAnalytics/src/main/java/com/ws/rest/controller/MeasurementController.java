package com.ws.rest.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ws.rest.pojo.AirwayDimensionRequest;
import com.ws.rest.pojo.AirwayDimensionResponse;
import com.ws.rest.pojo.Dimensions;
import com.ws.rest.service.MeasurementService;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


import javax.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;


/**
 * Created by n465449 on 13-Feb-18.
 */
@RestController
public class MeasurementController {

    @Autowired
    private MeasurementService service;

    private static final Logger LOGGER =  LogManager.getLogger(MeasurementController.class);


    @RequestMapping(value = "/dimensions", method = RequestMethod.GET,headers="Accept=application/json")
    public Map<String,AirwayDimensionResponse> getAllDimensions()
    {
        Map<String,AirwayDimensionResponse> results = service.getAirwayDetails();

        return  results;
    }

    @RequestMapping(value = "/dimensions", method = RequestMethod.POST,headers="Accept=application/json")
    public Response getDimensions(@RequestBody AirwayDimensionRequest request)
    {
        LOGGER.info("--------------MeasurementController------------------");
        LOGGER.info("AirwayDimensionRequest :"+request);

        Map<String,AirwayDimensionResponse> results = service.getAirwayUpdate(request);

        return  Response.status(Response.Status.OK).entity(results).build();
    }



    @RequestMapping(value = "/dimensions/{id}", method = RequestMethod.GET,headers="Accept=application/json")
    public Map<String,AirwayDimensionResponse> getDimensionById(@PathVariable("id") String id)
    {
        LOGGER.info("GetById---------------------"+id);
        Map<String,AirwayDimensionResponse> results = service.getDimensionsById(id);
        return  results;
    }

    @RequestMapping(value = "/dimensions/{id}/{pId}", method = RequestMethod.POST,headers="Accept=application/json")
    public Response removeDimensionById(@PathVariable("id") String id , @PathVariable("pId") String pId)
    {
        LOGGER.info("RemoveById---------------------"+id+"-"+pId);
        if(service.removeBarCode(id,pId))
        {
            return  Response.status(Response.Status.OK).entity("removed").build();
        }
        else
        {
            return  Response.status(Response.Status.OK).entity("not removed").build();
        }

    }


    @RequestMapping(value = "/js", method = RequestMethod.GET,headers="Accept=application/json")
    public List<AirwayDimensionResponse> getJSDimensions()
    {
        LOGGER.info("GetJs---------------------");
        List<AirwayDimensionResponse> results = service.getAirwayDetailList();
        LOGGER.info("GetById--------------------- results:"+results);
        return  results;
    }

}
