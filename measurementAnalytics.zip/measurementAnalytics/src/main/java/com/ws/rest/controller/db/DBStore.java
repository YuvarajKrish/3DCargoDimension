package com.ws.rest.controller.db;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.ws.rest.pojo.AirwayConstant;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Created by n465449 on 15-Feb-18.
 */
public class DBStore {

   /* @Autowired
    private BasicAWSCredentials awsCreds;
*/
    public Table table;

    private String serviceEndPoint ;
    private String signingRegion ;
    private String accessKey ;
    private String secretKey ;



    DBStore(String serviceEndPoint , String signingRegion)
    {
        String accessKey ="AKIAIA4H744NZ5RNKOVA";
        String secretKey ="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";

        System.out.println("DBStore - Ep:["+serviceEndPoint+"] Region:["+signingRegion+"] access:["+accessKey+"] sec:["+secretKey+"]");
        AmazonDynamoDB client = AmazonDynamoDBClientBuilder.standard().withCredentials(new AWSStaticCredentialsProvider(new BasicAWSCredentials(accessKey,secretKey)))
                .withEndpointConfiguration(new AwsClientBuilder.EndpointConfiguration(serviceEndPoint, signingRegion)) //.withEndpointConfiguration(new AwsClientBuilder.EndpointConfiguration("http://localhost:8000", "ap-south-1"))
                .build();

        DynamoDB dynamoDB = new DynamoDB(client);
        table = dynamoDB.getTable(AirwayConstant.AIRWAY_TABLE);
        System.out.println("DBStore - Table:["+table+"]");
    }

    public String getServiceEndPoint() {
        return serviceEndPoint;
    }

    public void setServiceEndPoint(String serviceEndPoint) {
        this.serviceEndPoint = serviceEndPoint;
    }

    public String getSigningRegion() {
        return signingRegion;
    }

    public void setSigningRegion(String signingRegion) {
        this.signingRegion = signingRegion;
    }

    public String getAccessKey() {
        return accessKey;
    }

    public void setAccessKey(String accessKey) {
        this.accessKey = accessKey;
    }

    public String getSecretKey() {
        return secretKey;
    }

    public void setSecretKey(String secretKey) {
        this.secretKey = secretKey;
    }

    public Table getTable() {
        return table;
    }

  /*  public BasicAWSCredentials getAwsCreds() {
        return awsCreds;
    }

    public void setAwsCreds(BasicAWSCredentials awsCreds) {
        this.awsCreds = awsCreds;
    }*/

    public void setTable(Table table) {
        this.table = table;
    }
}
