package com.ws.rest.pojo;

/**
 * Created by n465449 on 19-Feb-18.
 */
public class AirwayDimensionResponse {

    private String airWayBarCode;
    private String pieceId;
    private Dimensions dimensions;


    public String getAirWayBarCode() {
        return airWayBarCode;
    }

    public void setAirWayBarCode(String airWayBarCode) {
        this.airWayBarCode = airWayBarCode;
    }

    public String getPieceId() {
        return pieceId;
    }

    public void setPieceId(String pieceId) {
        this.pieceId = pieceId;
    }

    public Dimensions getDimensions() {
        return dimensions;
    }

    public void setDimensions(Dimensions dimensions) {
        this.dimensions = dimensions;
    }

    @Override
    public String toString() {
        return "AirwayDimensionResponse{" +
                "airWayBarCode='" + airWayBarCode + '\'' +
                ", pieceId='" + pieceId + '\'' +
                ", dimensions=" + dimensions +
                '}';
    }
}
