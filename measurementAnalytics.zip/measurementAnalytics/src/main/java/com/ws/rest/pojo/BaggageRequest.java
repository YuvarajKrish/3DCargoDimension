package com.ws.rest.pojo;

/**
 * Created by n465449 on 15-Feb-18.
 */
public class BaggageRequest {


    private Airline airLineDetails;

    private Dimensions dimension;

    public Airline getAirLineDetails() {
        return airLineDetails;
    }

    public void setAirLineDetails(Airline airLineDetails) {
        this.airLineDetails = airLineDetails;
    }

    public Dimensions getDimension() {
        return dimension;
    }

    public void setDimension(Dimensions dimension) {
        this.dimension = dimension;
    }
}
