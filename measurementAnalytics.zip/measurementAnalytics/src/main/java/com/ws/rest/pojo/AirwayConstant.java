package com.ws.rest.pojo;

/**
 * Created by n465449 on 19-Feb-18.
 */
public class AirwayConstant {

    public static final String AIRWAY_TABLE="CARGO_DIMENSIONS";
    public static final String PIECE_ID="pieceId";
    public static final String AIRWAY_BAR_ID="airWayBarCode";
    public static final String AIRWAY_BILL_NUM="airWayBillNo";

    public static final String DIMENSIONS="dimensions";
    public static final String HEIGHT="height";
    public static final String MANUAL_HEIGHT="manualHeight";
    public static final String LENGTH="lengths";
    public static final String MANUAL_LENGTH="manualLengths";
    public static final String WIDTH="width";
    public static final String MANUAL_WIDTH="manualWidth";


}
