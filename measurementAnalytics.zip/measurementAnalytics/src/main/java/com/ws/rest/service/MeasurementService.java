package com.ws.rest.service;

import com.ws.rest.controller.db.MeasurementDaoImpl;
import com.ws.rest.pojo.AirwayDimensionRequest;
import com.ws.rest.pojo.AirwayDimensionResponse;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.*;

/**
 * Created by n465449 on 15-Feb-18.
 */
public class MeasurementService {


    @Autowired
    private MeasurementDaoImpl measurementDao;

    private static final Logger LOGGER =  LogManager.getLogger(MeasurementService.class);


    public Map<String,AirwayDimensionResponse> getAirwayUpdate(AirwayDimensionRequest request)
    {

        LOGGER.info("MeasurementService-----------getAirwayUpdate----------");

        boolean results = false;
        Map<String,AirwayDimensionResponse> listResults = measurementDao.getDimensionsList();

        if(null != listResults && null != listResults.get(request.getAirWayBarCode()))
        {
             LOGGER.info("Update-----------");
            results = measurementDao.updateDimensions(request);
        }
        else
        {
             LOGGER.info("Insert-----------");
            results = measurementDao.storeDimensions(request);
        }

         LOGGER.info("Resuls of Insert/Update:"+results);

        if(results)
            listResults = measurementDao.getDimensionsList();

        return listResults;
    }

    public Map<String,AirwayDimensionResponse> getAirwayDetails()
    {
        LOGGER.info("MeasurementService-----------getAirwayDetails----------");
        return   measurementDao.getDimensionsList();
    }

    public List<AirwayDimensionResponse> getAirwayDetailList()
    {
        LOGGER.info("MeasurementService-----------getAirwayDetailList----------");
        return new ArrayList<AirwayDimensionResponse>(measurementDao.getDimensionsList().values());
    }

    public boolean removeBarCode(String id ,String pId)
    {
        LOGGER.info("MeasurementService-----------removeBarCode----------");
       return measurementDao.removeDimensions(id,pId);
    }

    public Map<String,AirwayDimensionResponse> getDimensionsById(String id)
    {
        LOGGER.info("MeasurementService-----------getDimensionsById----------");
        return measurementDao.getDimensionsById(id);
    }
}
