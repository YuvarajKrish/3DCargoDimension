package com.ws.rest.controller.db.aws;


import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.spec.GetItemSpec;
import com.amazonaws.services.dynamodbv2.model.*;

import java.util.Arrays;

public class DynamoDBLocalFixture {

    public static void main(String[] args) throws Exception {

        BasicAWSCredentials awsCreds = new BasicAWSCredentials("AKIAIA4H744NZ5RNKOVA", "aDzCKHi5gQnTLrB+JxDwubXmJm5b0SpCIBx7azr3");
        AmazonDynamoDB client = AmazonDynamoDBClientBuilder.standard().withCredentials(new AWSStaticCredentialsProvider(awsCreds))
                .withEndpointConfiguration(new AwsClientBuilder.EndpointConfiguration("http://localhost:8000", "ap-south-1"))
                .build();

        DynamoDB dynamoDB = new DynamoDB(client);

//        String tableName = "Movies";

        try {
            String tableName = "CARGO_DIMENSIONS";
            System.out.println("Attempting to create table; please wait...");

            Table table = dynamoDB.createTable(tableName,
                    Arrays.asList(new KeySchemaElement("airWayBarCode", KeyType.HASH), // Partition  key
                            new KeySchemaElement("pieceId", KeyType.RANGE)), // Sort key
                    Arrays.asList(new AttributeDefinition("airWayBarCode", ScalarAttributeType.S),
                            new AttributeDefinition("pieceId", ScalarAttributeType.N)),
                    new ProvisionedThroughput(1L, 1L));
            table.waitForActive();

            System.out.println("Success.  Table status: " + table.getDescription().getTableStatus());

        }
        catch (Exception e) {
            System.err.println("Unable to create table: ");
            System.err.println(e.getMessage());
        }


    }
}