package com.ws.rest.controller.db;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.document.*;
import com.amazonaws.services.dynamodbv2.document.spec.DeleteItemSpec;
import com.amazonaws.services.dynamodbv2.document.spec.ScanSpec;
import com.amazonaws.services.dynamodbv2.document.spec.UpdateItemSpec;
import com.amazonaws.services.dynamodbv2.document.utils.NameMap;
import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;
import com.amazonaws.services.dynamodbv2.model.ReturnValue;
import com.google.gson.Gson;
import com.ws.rest.pojo.AirwayConstant;
import com.ws.rest.pojo.AirwayDimensionRequest;
import com.ws.rest.pojo.AirwayDimensionResponse;
import com.ws.rest.pojo.Dimensions;
import com.ws.rest.service.MeasurementService;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.*;

/**
 * Created by n465449 on 15-Feb-18.
 */
public class MeasurementDaoImpl {


    private ScanSpec scanSpec;

    private Table table;

    @Autowired
    private DBStore dbStore;

    private static final Logger LOGGER =  LogManager.getLogger(MeasurementDaoImpl.class);

    public Map<String,AirwayDimensionResponse> getDimensionsList()
     {
         LOGGER.info("---------------- getDimensionsList ------------------");
         ScanSpec scanSpec = new ScanSpec().withProjectionExpression(AirwayConstant.AIRWAY_BAR_ID+","+AirwayConstant.PIECE_ID+","
                 +AirwayConstant.DIMENSIONS+"."+AirwayConstant.HEIGHT+","
                 +AirwayConstant.DIMENSIONS+"."+AirwayConstant.LENGTH+","
                 +AirwayConstant.DIMENSIONS+"."+AirwayConstant.WIDTH+","
                 +AirwayConstant.DIMENSIONS+"."+AirwayConstant.MANUAL_HEIGHT+","
                 +AirwayConstant.DIMENSIONS+"."+AirwayConstant.MANUAL_LENGTH+","
                 +AirwayConstant.DIMENSIONS+"."+AirwayConstant.MANUAL_WIDTH);
         Map<String,AirwayDimensionResponse> map = new HashMap<>();
         try {

             ItemCollection<ScanOutcome> items = table.scan(scanSpec);
             Gson gson = new Gson();

             Iterator<Item> iter = items.iterator();
             while (iter.hasNext()) {
                 Item item = iter.next();
                 AirwayDimensionResponse response = new AirwayDimensionResponse();

                 Dimensions dimensions = gson.fromJson(item.get("dimensions").toString(),Dimensions.class);

                  LOGGER.info("String:"+AirwayConstant.DIMENSIONS+"."+AirwayConstant.LENGTH);
                  LOGGER.info("Item:"+item.toString());

                 response.setAirWayBarCode(item.getString(AirwayConstant.AIRWAY_BAR_ID));
                 response.setPieceId(item.getString(AirwayConstant.PIECE_ID));

                 response.setDimensions(dimensions);

                  LOGGER.info(response);
                 map.put(response.getAirWayBarCode(),response);
             }

              LOGGER.info("Map:"+map);
         }
         catch (Exception e) {
              LOGGER.info("Unable to scan the table:");
              LOGGER.info(e.getMessage());
         }

         return map;
     }

    public Map<String,AirwayDimensionResponse> getDimensionsById(String id)
    {
        LOGGER.info("---------------- getDimensionsList BY ID ------------------"+id);
        Map<String,AirwayDimensionResponse> map = getDimensionsList();
        Map<String,AirwayDimensionResponse> singleMap = new HashMap<String, AirwayDimensionResponse>();
        singleMap.put(id,map.get(id));
        return singleMap;
    }

    public boolean storeDimensions(AirwayDimensionRequest request)
    {

         LOGGER.info("---------------- Insert ------------------");

        boolean results = true;
        final Map<String, Object> infoMap = new HashMap<String, Object>();
        infoMap.put(AirwayConstant.HEIGHT,request.getDimensions().getHeight());
        infoMap.put(AirwayConstant.LENGTH,request.getDimensions().getLength());
        infoMap.put(AirwayConstant.WIDTH,request.getDimensions().getWidth());
        infoMap.put(AirwayConstant.MANUAL_HEIGHT,request.getDimensions().getManualHeight());
        infoMap.put(AirwayConstant.MANUAL_LENGTH,request.getDimensions().getManualLengths());
        infoMap.put(AirwayConstant.MANUAL_WIDTH,request.getDimensions().getManualWidth());

        try
        {
            LOGGER.info("Adding a new item...");
            PutItemOutcome outcome = table.putItem(new Item().withPrimaryKey(AirwayConstant.AIRWAY_BAR_ID, request.getAirWayBarCode())
                    .withInt(AirwayConstant.PIECE_ID, Integer.parseInt(request.getPieceId())).withMap(AirwayConstant.DIMENSIONS, infoMap));
            LOGGER.info("outcome.getItem:"+outcome.getItem());
             LOGGER.info("PutItem succeeded:\n" + outcome.getPutItemResult());

        }
        catch (Exception e) {
             LOGGER.info("Unable to add item: " +request);
             LOGGER.info(e.getMessage());
            results = false;
        }

        return results;
    }


    public boolean updateDimensions(AirwayDimensionRequest request)
    {

         LOGGER.info("---------------- Update ------------------");
        boolean results = false;
        String updateStr = "";

        ValueMap vMap = null;

        if(Integer.parseInt(request.getDimensions().getManualHeight()) > 0
                 && Integer.parseInt(request.getDimensions().getManualLengths()) > 0
                 && Integer.parseInt(request.getDimensions().getManualWidth()) > 0
                && Integer.parseInt(request.getDimensions().getHeight()) == 0
                && Integer.parseInt(request.getDimensions().getLength()) == 0
                && Integer.parseInt(request.getDimensions().getWidth()) == 0
                 )
        {
             updateStr = "set "+AirwayConstant.DIMENSIONS+"."+AirwayConstant.MANUAL_HEIGHT+"=:h, "+AirwayConstant.DIMENSIONS+"."+AirwayConstant.MANUAL_LENGTH+"=:l, "
                    +AirwayConstant.DIMENSIONS+"."+AirwayConstant.MANUAL_WIDTH+"=:w";

            vMap= new ValueMap().withNumber(":h",  Integer.parseInt(request.getDimensions().getManualHeight()))
                    .withNumber(":l",  Integer.parseInt(request.getDimensions().getManualLengths()))
                    .withNumber(":w",  Integer.parseInt(request.getDimensions().getManualWidth())) ;
        }
        else if(Integer.parseInt(request.getDimensions().getHeight()) > 0
                && Integer.parseInt(request.getDimensions().getLength()) > 0
                && Integer.parseInt(request.getDimensions().getWidth()) > 0
                && Integer.parseInt(request.getDimensions().getManualHeight()) == 0
                && Integer.parseInt(request.getDimensions().getManualLengths()) == 0
                && Integer.parseInt(request.getDimensions().getManualWidth()) == 0
                )
        {
             updateStr = "set "+AirwayConstant.DIMENSIONS+"."+AirwayConstant.HEIGHT+"=:h, "+AirwayConstant.DIMENSIONS+"."+AirwayConstant.LENGTH+"=:l, "
                    +AirwayConstant.DIMENSIONS+"."+AirwayConstant.WIDTH+"=:w";
            vMap= new ValueMap().withNumber(":h",  Integer.parseInt(request.getDimensions().getHeight()))
                    .withNumber(":l",  Integer.parseInt(request.getDimensions().getLength()))
                    .withNumber(":w",  Integer.parseInt(request.getDimensions().getWidth())) ;
        }


        if( null != vMap)
        {
            UpdateItemSpec updateItemSpec = new UpdateItemSpec().withPrimaryKey(AirwayConstant.AIRWAY_BAR_ID, request.getAirWayBarCode(),
                    AirwayConstant.PIECE_ID, Integer.parseInt(request.getPieceId()))
                    .withUpdateExpression(updateStr)
                    .withValueMap(vMap)
                    .withReturnValues(ReturnValue.UPDATED_NEW);

            try {

                UpdateItemOutcome outcome = table.updateItem(updateItemSpec);
                LOGGER.info("UpdateItem succeeded:\n" + outcome.getItem().toJSONPretty());
                results = true;
            }
            catch (Exception e) {
                LOGGER.info("Unable to update item: " +request);
                LOGGER.info(e.getMessage());
                results = false;
            }
        }


        return results;

    }

    public boolean removeDimensions(String barId , String pId)
    {

        boolean result ;
         LOGGER.info("---------------- Remove ------------------");
        try {

            DeleteItemSpec deleteItemSpec = new DeleteItemSpec().withPrimaryKey(AirwayConstant.AIRWAY_BAR_ID, barId,AirwayConstant.PIECE_ID,Integer.parseInt(pId));

            DeleteItemOutcome outcome = table.deleteItem(deleteItemSpec);

            // Check the response.
             LOGGER.info("Printing item that was deleted...");
             LOGGER.info(outcome.getItem().toJSONPretty());
            result = true;
        }
        catch (Exception e) {
             LOGGER.info("Error deleting item in " + barId);
             LOGGER.info(e.getMessage());
            result = false;
        }

        return result;
    }


    MeasurementDaoImpl(DBStore dbStore)
    {
        table = dbStore.getTable();
    }

}
